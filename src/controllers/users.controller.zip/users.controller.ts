import {
  Controller,
  Post,
  Get,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  HttpStatus,
  UseGuards,
  Request,
} from '@nestjs/common';
import { JWTService } from '../services/jwt/jwt.service';
import { WalletService } from '../services/wallet.service';
import { PaymentService } from '../services/payment.service';
import { WithdrawalService } from '../services/withdrawal.service';
import { ExternalApiService } from '../services/external-api/external-api.service';
import { WalletEntity } from '../entities/wallet.entity';
import { PaymentEntity } from '../entities/payment.entity';
import { WithdrawalEntity } from '../entities/withdrawal.entity';
import { CreateWalletDto } from '../dtos/wallet.dto';

// DTO interfaces for client operations
interface ClientSignupDto {
  fullName: string;
  email: string;
  phoneNumber: string;
  walletId: string;
  password: string;
}

interface ClientLoginDto {
  phoneNumber: string;
  password: string;
}

interface ClientProfileUpdateDto {
  fullName?: string;
  email?: string;
  phoneNumber?: string;
}

@Controller('users')
export class UsersController {
  constructor(
    private readonly jwtService: JWTService,
    private readonly walletService: WalletService,
    private readonly paymentService: PaymentService,
    private readonly withdrawalService: WithdrawalService,
    private readonly externalApiService: ExternalApiService,
  ) {}

  /**
   * Client signup endpoint - creates a new user with wallet
   * @param signupDto - Client signup data
   * @returns Promise<{ user: any; wallet: WalletEntity; token: string }>
   */
  @Post('signup')
  @HttpCode(HttpStatus.CREATED)
  async clientSignup(@Body() signupDto: ClientSignupDto) {
    // Create user in your authentication system (e.g., MongoDB, PostgreSQL)
    const user = {
      id: signupDto.walletId,
      fullName: signupDto.fullName,
      email: signupDto.email,
      phoneNumber: signupDto.phoneNumber,
      walletId: signupDto.walletId,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Create wallet for the user
    const wallet = await this.walletService.createWallet(
      user.id,
      'USD',
      0,
      user.phoneNumber,
    );

    // Generate JWT token
    const token = this.jwtService.generateToken({
      userId: user.id,
      walletId: wallet.id,
      fullName: user.fullName,
      email: user.email,
      phoneNumber: user.phoneNumber,
    });

    return {
      user,
      wallet,
      token,
    };
  }

  /**
   * Client login endpoint
   * @param loginDto - Client login credentials
   * @returns Promise<{ user: any; wallet: WalletEntity; token: string }>
   */
  @Post('login')
  @HttpCode(HttpStatus.OK)
  async clientLogin(@Body() loginDto: ClientLoginDto) {
    // Find user by phoneNumber and verify password (in real implementation)
    const user = {
      id: loginDto.phoneNumber, // Using phone number as user id for demonstration
      fullName: 'Client User', // This would come from your user database
      email: 'client@example.com', // This would come from your user database
      phoneNumber: loginDto.phoneNumber,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Get user's wallet
    const wallet = await this.walletService.findByPhone(user.phoneNumber);
    if (!wallet) {
      // Create wallet if not exists
      await this.walletService.createWallet(user.id, 'USD', 0, user.phoneNumber);
    }

    // Generate JWT token
    const token = this.jwtService.generateToken({
      userId: user.id,
      walletId: wallet?.id || user.id,
      fullName: user.fullName,
      email: user.email,
      phoneNumber: user.phoneNumber,
    });

    return {
      user,
      wallet: wallet || await this.walletService.findByPhone(user.phoneNumber),
      token,
    };
  }

  /**
   * Gets client profile data
   * @param req - Request object with user data
   * @returns Promise<{ user: any; wallet: WalletEntity }>
   */
  @Get('profile')
  @HttpCode(HttpStatus.OK)
  async getClientProfile(@Request() req) {
    const userId = req.user?.userId || req.user?.walletId;
    
    // Get user data from your authentication system
    const user = {
      id: userId,
      fullName: 'Client User', // This would come from your user database
      email: 'client@example.com', // This would come from your user database
      phoneNumber: '+1234567890', // This would come from your user database
      walletId: userId,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Get user's wallet
    const wallet = await this.walletService.findByUserId(userId);

    return {
      user,
      wallet,
    };
  }

  /**
   * Updates client profile
   * @param req - Request object with user data
   * @param updateDto - Profile update data
   * @returns Promise<{ user: any }>
   */
  @Put('profile')
  @HttpCode(HttpStatus.OK)
  async updateClientProfile(
    @Request() req,
    @Body() updateDto: ClientProfileUpdateDto,
  ) {
    const userId = req.user?.userId || req.user?.walletId;

    // Update user profile in your authentication system
    const updatedUser = {
      id: userId,
      fullName: updateDto.fullName || 'Client User',
      email: updateDto.email || 'client@example.com',
      phoneNumber: updateDto.phoneNumber || '+1234567890',
      walletId: userId,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    return {
      user: updatedUser,
    };
  }

  /**
   * Gets client dashboard data
   * @param req - Request object with user data
   * @returns Promise<object>
   */
  @Get('dashboard')
  @HttpCode(HttpStatus.OK)
  async getClientDashboard(@Request() req) {
    const userId = req.user?.userId || req.user?.walletId;

    // Get user's wallet
    const wallet = await this.walletService.findByUserId(userId);

    // Get user's payment history
    const payments = await this.paymentService.getPaymentsByUserId(userId);

    // Get user's withdrawal history
    const withdrawals = await this.withdrawalService.getWithdrawalsByUserId(userId);

    // Get user data to access phone number
    const user = {
      id: userId,
      fullName: 'Client User', // This would come from your user database
      email: 'client@example.com', // This would come from your user database
      phoneNumber: '+1234567890', // This would come from your user database
      walletId: userId,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Get all routers from external API and filter by user's phone number
    const routersResponse = await this.externalApiService.getRouters();
    const allRouters = routersResponse.data || [];
    const linkedRouters = allRouters.filter((router: any) => 
      router.holderContact === user.phoneNumber
    ).map((router: any, index: number) => ({
      id: `${index + 1}`,
      name: router.routerName || `Router-${index + 1}`,
      macAddress: router.routerIP || 'Unknown',
    }));

    // Get currently running tokens (this would be implemented based on your token management system)
    const currentlyRunningTokens = [
      { id: '1', tokenId: 'TWIST-8X9K2', router: 'Main-Lobby-R1', duration: '1hr', expiryTime: new Date(Date.now() + 3600000).toISOString(), status: 'active' },
      { id: '2', tokenId: 'TWIST-9L2M4', router: 'Pool-Area-AP', duration: '2hr', expiryTime: new Date(Date.now() + 7200000).toISOString(), status: 'active' },
    ];

    return {
      statistics: {
        currentBalance: wallet?.balance || 0,
        totalPayments: payments.length,
        totalWithdrawals: withdrawals.length,
        activeTokens: currentlyRunningTokens.length,
        linkedRouters: linkedRouters.length,
      },
      wallet,
      recentPayments: payments.slice(0, 5),
      recentWithdrawals: withdrawals.slice(0, 5),
      linkedRouters,
      currentlyRunningTokens,
    };
  }

  /**
   * Gets user's payment history
   * @param req - Request object with user data
   * @returns Promise<PaymentEntity[]>
   */
  @Get('payments')
  @HttpCode(HttpStatus.OK)
  async getClientPayments(@Request() req) {
    const userId = req.user?.userId || req.user?.walletId;
    return this.paymentService.getPaymentsByUserId(userId);
  }

  /**
   * Gets user's withdrawal history
   * @param req - Request object with user data
   * @returns Promise<WithdrawalEntity[]>
   */
  @Get('withdrawals')
  @HttpCode(HttpStatus.OK)
  async getClientWithdrawals(@Request() req) {
    const userId = req.user?.userId || req.user?.walletId;
    return this.withdrawalService.getWithdrawalsByUserId(userId);
  }

  /**
   * Generates vouchers for the client
   * @param req - Request object with user data
   * @param voucherData - Voucher generation data
   * @returns Promise<{ vouchers: any[] }>
   */
  @Post('vouchers')
  @HttpCode(HttpStatus.CREATED)
  async generateVouchers(
    @Request() req,
    @Body() voucherData: { quantity: number; duration: string },
  ) {
    const userId = req.user?.userId || req.user?.walletId;

    // Convert duration string to seconds for external API
    const durationInSeconds = this.getDurationMs(voucherData.duration) / 1000;

    // Call external API to generate bulk vouchers
    const response = await this.externalApiService.generateBulkVouchers(
      voucherData.quantity,
      durationInSeconds,
    );

    // Format the vouchers with additional details
    const vouchers = response.codes.map((tokenId: string, index: number) => ({
      id: `voucher-${Date.now()}-${index}`,
      tokenId: tokenId,
      router: 'Main-Lobby-R1', // This would be selected based on user's linked routers
      duration: voucherData.duration,
      expiryTime: new Date(Date.now() + this.getDurationMs(voucherData.duration)).toISOString(),
      status: 'active',
      createdBy: userId,
      createdAt: new Date(),
    }));

    return {
      vouchers,
    };
  }

  /**
   * Gets client's generated vouchers
   * @param req - Request object with user data
   * @returns Promise<{ vouchers: any[] }>
   */
  @Get('vouchers')
  @HttpCode(HttpStatus.OK)
  async getClientVouchers(@Request() req) {
    const userId = req.user?.userId || req.user?.walletId;

    // This would query your vouchers table/collection
    const vouchers = [
      {
        id: 'voucher-1',
        tokenId: 'TWIST-8X9K2',
        router: 'Main-Lobby-R1',
        duration: '1hr',
        expiryTime: new Date(Date.now() + 3600000).toISOString(),
        status: 'active',
        createdBy: userId,
        createdAt: new Date(),
      },
      {
        id: 'voucher-2',
        tokenId: 'TWIST-9L2M4',
        router: 'Pool-Area-AP',
        duration: '2hr',
        expiryTime: new Date(Date.now() + 7200000).toISOString(),
        status: 'active',
        createdBy: userId,
        createdAt: new Date(),
      },
    ];

    return {
      vouchers,
    };
  }

  /**
   * Helper method to convert duration string to milliseconds
   * @param duration - Duration string (e.g., '1hr', '2hr', '4hr', '8hr', '1day', '3day', '1week', '1month')
   * @returns number - Duration in milliseconds
   */
  private getDurationMs(duration: string): number {
    const durationMap: Record<string, number> = {
      '1hr': 3600000,
      '2hr': 7200000,
      '4hr': 14400000,
      '8hr': 28800000,
      '1day': 86400000,
      '3day': 259200000,
      '1week': 604800000,
      '1month': 2592000000,
    };

    return durationMap[duration] || 3600000; // Default to 1 hour
  }
}
